made by: shadesmaclean / Neko-Sen'nin
(Spooky Door Productions)
10/27/13
with: Skinamp
Dedicated to those who took a different path.
(Komika Boo font)
