made by: shadesmaclean / Neko-Sen'nin
(Spooky Door Productions)
07/20/13
with: Skinamp
Dedicated to those who know that time and tide wait for nopony.
(cosmoscandy font)
