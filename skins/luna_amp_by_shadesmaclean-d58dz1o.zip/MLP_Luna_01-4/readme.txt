made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
08/23/11
with: Skinamp
Dedicated to those who put their quarrels behind them.
(cloister black font)
