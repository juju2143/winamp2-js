made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
11/27/11
with: Skinamp
Dedicated to those who seek harmony in their life.
(bon jovi font)
