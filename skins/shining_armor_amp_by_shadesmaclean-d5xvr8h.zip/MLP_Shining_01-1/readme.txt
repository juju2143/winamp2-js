made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
03/12/13
with: Skinamp
Dedicated to those who can be as strong as they have to for the ones they care about.
(waltograph font)
