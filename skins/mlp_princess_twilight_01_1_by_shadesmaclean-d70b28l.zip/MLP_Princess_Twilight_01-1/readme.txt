made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
12/31/13
with: Skinamp
Dedicated to those who begin to live up to their true potential.
(carolingia font)
