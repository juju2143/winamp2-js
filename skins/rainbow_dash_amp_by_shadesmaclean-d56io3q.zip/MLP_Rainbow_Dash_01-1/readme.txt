made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
07/04/11
with: Skinamp
Dedicated to those who go the distance for their friends.
(bubblegum rock font)
