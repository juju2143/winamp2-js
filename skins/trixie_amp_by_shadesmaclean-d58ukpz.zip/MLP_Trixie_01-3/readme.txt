made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
10/25/11
with: Skinamp
Dedicated to those who suffer no shortage of confidence.
(harry p font)
