made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
11/23/12
with: Skinamp
Dedicated to those books that undeniably, unquestionably un-put-downable.
(adventure font)
