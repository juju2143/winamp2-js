made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
04/11/13
with: Skinamp
Dedicated to those who don't sweat the small stuff.
(dumbass font)
