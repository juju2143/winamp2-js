made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
09/05/11
with: Skinamp
Dedicated to my old friend, DJ Amaya.
(powerpuff font)

