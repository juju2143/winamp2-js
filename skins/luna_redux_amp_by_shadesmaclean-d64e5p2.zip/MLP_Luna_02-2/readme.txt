made by: shadesmaclean / Neko-Sen'nin
(Spooky Door Productions)
05/06/13
with: Skinamp
Dedicated to those who take second chances and turn things around.
(cloister black font)
