made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
07/25/11
with: Skinamp
Dedicated to friends you can depend on.
(western font)
