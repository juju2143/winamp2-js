made by: shadesmaclean / Neko-Sen'nin
(Spooky Door Productions)
12/06/13
with: Skinamp
Dedicated to anypony who's had one of those days.
(Dread font)
