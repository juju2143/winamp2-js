made by: shadesmaclean / Neko-Sen'nin
(Spooky Door Productions)
09/26/13
with: Skinamp
Dedicated to those who push themselves beyond their limits.
(Impossible 1000 font)
