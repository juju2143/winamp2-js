made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
09/11/12
with: Skinamp
Dedicated to those who take life as it comes.
(africa font)
