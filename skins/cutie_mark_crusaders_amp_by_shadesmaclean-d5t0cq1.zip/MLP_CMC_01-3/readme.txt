made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
01/28/13
with: Skinamp
Dedicated to those who seek out their true potential.
(allstars font)
