made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
07/11/11
with: Skinamp
Dedicated to those who see kindness as a strength.
(whimsy font)
