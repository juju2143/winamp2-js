made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
10/30/12
with: Skinamp
Dedicated to those who know what they want. :D
(abbadon font)
