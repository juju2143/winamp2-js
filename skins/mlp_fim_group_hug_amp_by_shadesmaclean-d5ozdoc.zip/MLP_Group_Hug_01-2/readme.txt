made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
12/21/12
with: Skinamp
Dedicated to those who stand todether, side by side in good times, back to back in bad.
(celestia redux font)
