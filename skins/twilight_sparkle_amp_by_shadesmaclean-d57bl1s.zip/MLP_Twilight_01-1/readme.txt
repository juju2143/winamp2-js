made by: Neko-Sen'nin / shadesmaclean
(Spooky Door Productions)
07/14/11
with: Skinamp
Dedicated to those who recognize true friends when they see them.
(carolingia font)
